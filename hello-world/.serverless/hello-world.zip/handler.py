import json


def hello(event, context):
   print("HI first change")

   return "Hello-world"

    # Use this code if you don't use the http event with the LAMBDA-PROXY
    # integration
